// scripts/main.ts
import { system as system2, world as world2, EntityDamageCause } from "@minecraft/server";

// scripts/data/gunHelpers.ts
function getAmmoItemId(type) {
  switch (type) {
    case "lmg":
      return "absolute_guns:machinegun_ammo";
    case "rifle":
      return "absolute_guns:rifle_ammo";
    case "pistol":
      return "absolute_guns:pistol_ammo";
    case "sniper":
      return "absolute_guns:sniper_ammo";
    case "shotgun":
      return "absolute_guns:shotgun_ammo";
    case "smg":
      return "absolute_guns:smg_ammo";
    default:
      return "absolute_guns:rifle_ammo";
  }
}
function getProjectileTypeId(type) {
  switch (type) {
    case "rifle":
      return "absolute_guns_bullet:gun";
    case "pistol":
      return "absolute_guns_bullet:gun";
    case "sniper":
      return "absolute_guns_bullet:gun";
    case "shotgun":
      return "absolute_guns_bullet:shotgun";
    case "smg":
      return "absolute_guns_bullet:gun";
    default:
      return "absolute_guns_bullet:gun";
  }
}
function createGun(input) {
  const { ammoTypeId, projectileTypeId, ...rest } = input;
  const computedAmmo = ammoTypeId ?? (rest.type === "special" ? rest.id === "absolute_guns:flamethrower" ? "minecraft:blaze_powder" : rest.id === "absolute_guns:rpg7" ? "absolute_guns:rpg7_ammo" : rest.id === "absolute_guns:mgl" ? "minecraft:tnt" : "absolute_guns:rifle_ammo" : getAmmoItemId(rest.type));
  const computedProjectile = projectileTypeId ?? (rest.type === "special" ? rest.id === "absolute_guns:flamethrower" ? "absolute_guns_bullet:flame" : rest.id === "absolute_guns:rpg7" ? "absolute_guns_bullet:rpg7" : rest.id === "absolute_guns:mgl" ? "absolute_guns_bullet:mgl" : "absolute_guns_bullet:gun" : getProjectileTypeId(rest.type));
  return {
    ...rest,
    ammoTypeId: computedAmmo,
    projectileTypeId: computedProjectile
  };
}

// scripts/data/guns.ts
var GUNS = [
  createGun({
    id: "absolute_guns:ak47",
    name: "AK47",
    type: "rifle",
    maxAmmo: 35,
    fireRate: 3,
    shootPower: 5,
    recoil: 0.0,
    reloadTime: 60,
    shootSound: "gun.abgak47",
    projectileTypeId: "absolute_guns_bullet:ak47",
    // Example weapon stats for the AK47 used by the new damage system
    stats: {
      damage: 4,
      damageDropOff: 0.04,
      armorPenetration: 0.2,
      maxRange: 90,
      knockback: { x: 0.0, y: 0.0 }
    }
  }),
  createGun({
    id: "absolute_guns:ak47_gold",
    name: "AK47 Gold",
    type: "rifle",
    maxAmmo: 60,
    fireRate: 2,
    shootPower: 5,
    recoil: 0.0,
    reloadTime: 40,
    shootSound: "gun.abgak47",
    projectileTypeId: "absolute_guns_bullet:ak47_gold",
    stats: {
      damage: 6.5,
      damageDropOff: 0.04,
      armorPenetration: 0.2,
      maxRange: 90,
      knockback: { x: 0.0, y: 0.0 }
    }
  }),
  createGun({
    id: "absolute_guns:ak74u",
    name: "AK74U",
    type: "rifle",
    maxAmmo: 25,
    fireRate: 3,
    shootPower: 5,
    recoil: 0.0,
    reloadTime: 50,
    shootSound: "gun.abgak47",
    projectileTypeId: "absolute_guns_bullet:ak74u",
    stats: {
      damage: 4,
      damageDropOff: 0.04,
      armorPenetration: 0.2,
      maxRange: 90,
      knockback: { x: 0.0, y: 0.0 }
    }
  }),
  createGun({
    id: "absolute_guns:ak74u_t1",
    name: "AK74U Upgraded",
    type: "rifle",
    maxAmmo: 74,
    fireRate: 1,
    shootPower: 5,
    recoil: 0.0,
    reloadTime: 25,
    shootSound: "gun.pap",
    projectileTypeId: "absolute_guns_bullet:ak74u_t1",
    stats: {
      damage: 10,
      damageDropOff: 0.04,
      armorPenetration: 0.2,
      maxRange: 90,
      knockback: { x: 0.5, y: 0.5 }
    }
  }),
  createGun({
    id: "absolute_guns:bizon",
    name: "Bizon",
    type: "smg",
    maxAmmo: 50,
    fireRate: 2,
    shootPower: 5,
    recoil: 0.0,
    reloadTime: 40,
    shootSound: "gun.abgbizon",
    projectileTypeId: "absolute_guns_bullet:bizon",
    stats: {
      damage: 6.5,
      damageDropOff: 0.05,
      armorPenetration: 0.2,
      maxRange: 90,
      knockback: { x: 0.0, y: 0.0 }
    }
  }),
  createGun({
    id: "absolute_guns:flamethrower",
    name: "Flamethrower",
    type: "special",
    maxAmmo: 100,
    fireRate: 2,
    shootPower: 5,
    recoil: 0.05,
    reloadTime: 80,
    shootSound: "gun.abgflamethrower",
    projectileTypeId: "absolute_guns_bullet:flame",
    stats: {
      damage: 1,
      damageDropOff: 0,
      armorPenetration: 0.2,
      maxRange: 12,
      knockback: { x: 0.5, y: 0.5 }
    }
  }),
  createGun({
    id: "absolute_guns:glock",
    name: "Glock",
    type: "pistol",
    maxAmmo: 16,
    fireRate: 6,
    shootPower: 5,
    recoil: 0.0,
    reloadTime: 20,
    ammoTypeId: "absolute_guns:pistol_ammo",
    mode: "semi" /* SEMI */,
    shootSound: "gun.abgglock",
    reloadAnimation: "animation.abg3.reload",
    drawAnimation: "animation.abg3.draw",
    shootAnimation: "animation.abg3.shoot",
    projectileTypeId: "absolute_guns_bullet:glock",
    stats: {
      damage: 4,
      damageDropOff: 0.06,
      armorPenetration: 0.2,
      maxRange: 90,
      knockback: { x: 0.0, y: 0.0 }
    }
  }),
  createGun({
    id: "absolute_guns:glock_tactical",
    name: "Glock Tactical",
    type: "pistol",
    maxAmmo: 20,
    fireRate: 5,
    shootPower: 5,
    recoil: 0.0,
    reloadTime: 20,
    shootSound: "gun.abgsilenced",
    ammoTypeId: "absolute_guns:pistol_ammo",
    projectileTypeId: "absolute_guns_bullet:glock_tactical",
    mode: "semi" /* SEMI */,
    stats: {
      damage: 4,
      damageDropOff: 0.06,
      armorPenetration: 0.2,
      maxRange: 90,
      knockback: { x: 0.0, y: 0.0 }
    }
  }),
  createGun({
    id: "absolute_guns:m1014",
    name: "M1014",
    type: "shotgun",
    maxAmmo: 12,
    fireRate: 20,
    shootPower: 1,
    recoil: 1,
    reloadTime: 60,
    shootSound: "gun.abgm1014",
    projectileTypeId: "absolute_guns_bullet:m1014",
    mode: "shotgun" /* SHOTGUN */,
    stats: {
      damage: 6,
      damageDropOff: 0,
      armorPenetration: 0.0,
      maxRange: 30,
      knockback: { x: 2, y: 2 }
    }
  }),
  createGun({
    id: "absolute_guns:m16",
    name: "M16",
    type: "rifle",
    maxAmmo: 35,
    fireRate: 3,
    shootPower: 5,
    recoil: 0.0,
    reloadTime: 60,
    shootSound: "gun.abgm4",
    projectileTypeId: "absolute_guns_bullet:m16",
    stats: {
      damage: 9,
      damageDropOff: 0.04,
      armorPenetration: 0.25,
      maxRange: 90,
      knockback: { x: 0.0, y: 0.0 }
    }
  }),
  createGun({
    id: "absolute_guns:m3",
    name: "M3",
    type: "shotgun",
    maxAmmo: 10,
    fireRate: 16,
    shootPower: 1,
    recoil: 1,
    reloadTime: 60,
    shootSound: "gun.abgm3",
    projectileTypeId: "absolute_guns_bullet:m3",
    mode: "shotgun" /* SHOTGUN */,
    stats: {
      damage: 3,
      damageDropOff: 0,
      armorPenetration: 0.1,
      maxRange: 30,
      knockback: { x: 2, y: 2 }
    }
  }),
  createGun({
    id: "absolute_guns:m4",
    name: "M4",
    type: "rifle",
    maxAmmo: 40,
    fireRate: 3,
    shootPower: 5,
    recoil: 0.0,
    reloadTime: 60,
    shootSound: "gun.abgm4",
    projectileTypeId: "absolute_guns_bullet:m4",
    stats: {
      damage: 5,
      damageDropOff: 0.04,
      armorPenetration: 0.25,
      maxRange: 90,
      knockback: { x: 0.0, y: 0.0 }
    }
  }),
  createGun({
    id: "absolute_guns:mg42",
    name: "MG42",
    type: "lmg",
    maxAmmo: 40,
    fireRate: 6,
    shootPower: 2,
    recoil: 0.0,
    reloadTime: 80,
    shootSound: "gun.abgmg42",
    projectileTypeId: "absolute_guns_bullet:mg42",
    stats: {
      damage: 6.5,
      damageDropOff: 0.03,
      armorPenetration: 0.3,
      maxRange: 90,
      knockback: { x: 1.0, y: 1.0 }
    }
  }),
  createGun({
    id: "absolute_guns:mgl",
    name: "MGL",
    type: "special",
    maxAmmo: 2,
    fireRate: 16,
    shootPower: 1,
    recoil: 0.3,
    reloadTime: 120,
    ammoTypeId: "minecraft:tnt",
    projectileTypeId: "absolute_guns_bullet:mgl",
    shootSound: "gun.abgmgl",
    stats: {
      damage: 25,
      damageDropOff: 0,
      armorPenetration: 0.5,
      maxRange: 50,
      knockback: { x: 2, y: 2 }
    }
  }),
  createGun({
    id: "absolute_guns:mp40",
    name: "MP40",
    type: "smg",
    maxAmmo: 30,
    fireRate: 3,
    shootPower: 5,
    recoil: 0.0,
    reloadTime: 40,
    shootSound: "gun.abgmp40",
    projectileTypeId: "absolute_guns_bullet:mp40",
    stats: {
      damage: 3,
      damageDropOff: 0.05,
      armorPenetration: 0.15,
      maxRange: 90,
      knockback: { x: 0.0, y: 0.0 }
    }
  }),
  createGun({
    id: "absolute_guns:mp5",
    name: "MP5",
    type: "smg",
    maxAmmo: 35,
    fireRate: 2,
    shootPower: 5,
    recoil: 0.0,
    reloadTime: 40,
    shootSound: "gun.abgmp5",
    projectileTypeId: "absolute_guns_bullet:mp5",
    stats: {
      damage: 3,
      damageDropOff: 0.05,
      armorPenetration: 0.2,
      maxRange: 90,
      knockback: { x: 0.0, y: 0.0 }
    }
  }),
  createGun({
    id: "absolute_guns:mp5k",
    name: "MP5K",
    type: "smg",
    maxAmmo: 36,
    fireRate: 2,
    shootPower: 5,
    recoil: 0.0,
    reloadTime: 40,
    shootSound: "gun.abgmp5",
    projectileTypeId: "absolute_guns_bullet:mp5k",
    stats: {
      damage: 7,
      damageDropOff: 0.05,
      armorPenetration: 0.2,
      maxRange: 90,
      knockback: { x: 0.0, y: 0.0 }
    }
  }),
  createGun({
    id: "absolute_guns:pkm",
    name: "PKM",
    type: "lmg",
    maxAmmo: 45,
    fireRate: 4,
    shootPower: 2,
    recoil: 0.0,
    reloadTime: 90,
    shootSound: "gun.abgak47",
    projectileTypeId: "absolute_guns_bullet:pkm",
    stats: {
      damage: 8,
      damageDropOff: 0.03,
      armorPenetration: 0.3,
      maxRange: 90,
      knockback: { x: 1.0, y: 1.0 }
    }
  }),
  createGun({
    id: "absolute_guns:rpg7",
    name: "RPG7",
    type: "special",
    maxAmmo: 1,
    fireRate: 40,
    shootPower: 2,
    recoil: 2,
    reloadTime: 100,
    ammoTypeId: "absolute_guns:rpg7_ammo",
    reloadAnimation: "animation.simple_reload50",
    projectileTypeId: "absolute_guns_bullet:rpg7",
    shootSound: "gun.abgrpg7",
    stats: {
      damage: 50,
      damageDropOff: 0,
      armorPenetration: 1,
      maxRange: 100,
      knockback: { x: 3, y: 3 }
    }
  }),
  createGun({
    id: "absolute_guns:rpk",
    name: "RPK",
    type: "lmg",
    maxAmmo: 45,
    fireRate: 5,
    shootPower: 2,
    recoil: 0.0,
    reloadTime: 100,
    shootSound: "gun.abgak47",
    projectileTypeId: "absolute_guns_bullet:rpk",
    stats: {
      damage: 6.5,
      damageDropOff: 0.03,
      armorPenetration: 0.25,
      maxRange: 90,
      knockback: { x: 0.5, y: 0.5 }
    }
  }),
  createGun({
    id: "absolute_guns:spas",
    name: "SPAS",
    type: "shotgun",
    maxAmmo: 12,
    fireRate: 12,
    shootPower: 2,
    recoil: 1,
    reloadTime: 60,
    reloadAnimation: "animation.simple_reload30",
    drawAnimation: "animation.abg3.draw",
    shootAnimation: "animation.abg3.shoot",
    mode: "shotgun" /* SHOTGUN */,
    shootSound: "gun.abgm1014",
    projectileTypeId: "absolute_guns_bullet:m1014",
    stats: {
      damage: 13.5,
      damageDropOff: 0,
      armorPenetration: 0.1,
      maxRange: 30,
      knockback: { x: 2, y: 2 }
    }
  }),
  createGun({
    id: "absolute_guns:ump45",
    name: "UMP45",
    type: "smg",
    maxAmmo: 35,
    fireRate: 2,
    shootPower: 2,
    recoil: 0.0,
    reloadTime: 50,
    shootSound: "gun.abgump45",
    projectileTypeId: "absolute_guns_bullet:ump45",
    stats: {
      damage: 4,
      damageDropOff: 0.05,
      armorPenetration: 0.2,
      maxRange: 90,
      knockback: { x: 0.0, y: 0.0 }
    }
  })
];
function sanitizeObjectiveId(input) {
  return input.replace(/[^a-zA-Z0-9_]/g, "_");
}
function dynamicPropertyKeyForGun(gun) {
  return `abg_ammo_${sanitizeObjectiveId(gun.id)}`;
}
function ensurePlayerAmmoInitialized(player, gun) {
  try {
    const key = dynamicPropertyKeyForGun(gun);
    const existing = player.getDynamicProperty(key);
    if (existing === void 0 || typeof existing !== "number") {
      try {
        player.setDynamicProperty(key, gun.maxAmmo);
      } catch {
      }
    }
  } catch {
  }
}
function getPlayerAmmo(player, gun) {
  try {
    const key = dynamicPropertyKeyForGun(gun);
    const val = player.getDynamicProperty(key);
    if (typeof val === "number") return val;
    return gun.maxAmmo;
  } catch {
    return gun.maxAmmo;
  }
}
function setPlayerAmmo(player, gun, amount) {
  try {
    const key = dynamicPropertyKeyForGun(gun);
    player.setDynamicProperty(key, amount);
  } catch {
  }
}
function decreasePlayerAmmo(player, gun, amount = 1) {
  try {
    const cur = getPlayerAmmo(player, gun);
    if (cur <= 0) return false;
    setPlayerAmmo(player, gun, Math.max(0, cur - amount));
    return true;
  } catch {
    return false;
  }
}
var playerFireCooldowns = /* @__PURE__ */ new Map();
// ✅ CHANGED: Now stores {gunId, ticksRemaining} instead of just ticks
var playerReloadCooldowns = /* @__PURE__ */ new Map();

// node_modules/@minecraft/math/lib/general/clamp.js
function clampNumber(val, min, max) {
  return Math.min(Math.max(val, min), max);
}

// node_modules/@minecraft/math/lib/vector3/coreHelpers.js
var Vector3Utils = class _Vector3Utils {
  /**
   * equals
   *
   * Check the equality of two vectors
   */
  static equals(v1, v2) {
    return v1.x === v2.x && v1.y === v2.y && v1.z === v2.z;
  }
  /**
   * add
   *
   * Add two vectors to produce a new vector
   */
  static add(v1, v2) {
    return { x: v1.x + (v2.x ?? 0), y: v1.y + (v2.y ?? 0), z: v1.z + (v2.z ?? 0) };
  }
  /**
   * subtract
   *
   * Subtract two vectors to produce a new vector (v1-v2)
   */
  static subtract(v1, v2) {
    return { x: v1.x - (v2.x ?? 0), y: v1.y - (v2.y ?? 0), z: v1.z - (v2.z ?? 0) };
  }
  /** scale
   *
   * Multiple all entries in a vector by a single scalar value producing a new vector
   */
  static scale(v1, scale) {
    return { x: v1.x * scale, y: v1.y * scale, z: v1.z * scale };
  }
  /**
   * dot
   *
   * Calculate the dot product of two vectors
   */
  static dot(a, b) {
    return a.x * b.x + a.y * b.y + a.z * b.z;
  }
  /**
   * cross
   *
   * Calculate the cross product of two vectors. Returns a new vector.
   */
  static cross(a, b) {
    return { x: a.y * b.z - a.z * b.y, y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x };
  }
  /**
   * magnitude
   *
   * The magnitude of a vector
   */
  static magnitude(v) {
    return Math.sqrt(v.x ** 2 + v.y ** 2 + v.z ** 2);
  }
  /**
   * distance
   *
   * Calculate the distance between two vectors
   */
  static distance(a, b) {
    return _Vector3Utils.magnitude(_Vector3Utils.subtract(a, b));
  }
  /**
   * normalize
   *
   * Takes a vector 3 and normalizes it to a unit vector
   */
  static normalize(v) {
    const mag = _Vector3Utils.magnitude(v);
    return { x: v.x / mag, y: v.y / mag, z: v.z / mag };
  }
  /**
   * floor
   *
   * Floor the components of a vector to produce a new vector
   */
  static floor(v) {
    return { x: Math.floor(v.x), y: Math.floor(v.y), z: Math.floor(v.z) };
  }
  /**
   * toString
   *
   * Create a string representation of a vector3
   */
  static toString(v, options) {
    const decimals = options?.decimals ?? 2;
    const str = [v.x.toFixed(decimals), v.y.toFixed(decimals), v.z.toFixed(decimals)];
    return str.join(options?.delimiter ?? ", ");
  }
  /**
   * fromString
   *
   * Gets a Vector3 from the string representation produced by {@link Vector3Utils.toString}. If any numeric value is not a number
   * or the format is invalid, undefined is returned.
   * @param str - The string to parse
   * @param delimiter - The delimiter used to separate the components. Defaults to the same as the default for {@link Vector3Utils.toString}
   */
  static fromString(str, delimiter = ",") {
    const parts = str.split(delimiter);
    if (parts.length !== 3) {
      return void 0;
    }
    const output = parts.map((part) => parseFloat(part));
    if (output.some((part) => isNaN(part))) {
      return void 0;
    }
    return { x: output[0], y: output[1], z: output[2] };
  }
  /**
   * clamp
   *
   * Clamps the components of a vector to limits to produce a new vector
   */
  static clamp(v, limits) {
    return {
      x: clampNumber(v.x, limits?.min?.x ?? Number.MIN_SAFE_INTEGER, limits?.max?.x ?? Number.MAX_SAFE_INTEGER),
      y: clampNumber(v.y, limits?.min?.y ?? Number.MIN_SAFE_INTEGER, limits?.max?.y ?? Number.MAX_SAFE_INTEGER),
      z: clampNumber(v.z, limits?.min?.z ?? Number.MIN_SAFE_INTEGER, limits?.max?.z ?? Number.MAX_SAFE_INTEGER)
    };
  }
  /**
   * lerp
   *
   * Constructs a new vector using linear interpolation on each component from two vectors.
   */
  static lerp(a, b, t) {
    return { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t, z: a.z + (b.z - a.z) * t };
  }
  /**
   * slerp
   *
   * Constructs a new vector using spherical linear interpolation on each component from two vectors.
   */
  static slerp(a, b, t) {
    const theta = Math.acos(_Vector3Utils.dot(a, b));
    const sinTheta = Math.sin(theta);
    const ta = Math.sin((1 - t) * theta) / sinTheta;
    const tb = Math.sin(t * theta) / sinTheta;
    return _Vector3Utils.add(_Vector3Utils.scale(a, ta), _Vector3Utils.scale(b, tb));
  }
  /**
   * multiply
   *
   * Element-wise multiplication of two vectors together.
   * Not to be confused with {@link Vector3Utils.dot} product or {@link Vector3Utils.cross} product
   */
  static multiply(a, b) {
    return { x: a.x * b.x, y: a.y * b.y, z: a.z * b.z };
  }
  /**
   * rotateX
   *
   * Rotates the vector around the x axis counterclockwise (left hand rule)
   * @param a - Angle in radians
   */
  static rotateX(v, a) {
    const cos = Math.cos(a);
    const sin = Math.sin(a);
    return { x: v.x, y: v.y * cos - v.z * sin, z: v.z * cos + v.y * sin };
  }
  /**
   * rotateY
   *
   * Rotates the vector around the y axis counterclockwise (left hand rule)
   * @param a - Angle in radians
   */
  static rotateY(v, a) {
    const cos = Math.cos(a);
    const sin = Math.sin(a);
    return { x: v.x * cos + v.z * sin, y: v.y, z: v.z * cos - v.x * sin };
  }
  /**
   * rotateZ
   *
   * Rotates the vector around the z axis counterclockwise (left hand rule)
   * @param a - Angle in radians
   */
  static rotateZ(v, a) {
    const cos = Math.cos(a);
    const sin = Math.sin(a);
    return { x: v.x * cos - v.y * sin, y: v.y * cos + v.x * sin, z: v.z };
  }
};

// scripts/feature/utils/shootUtils.ts
function getSpawnLoc(player, gun) {
  const headPos = player.getHeadLocation();
  const viewDir = player.getViewDirection();
  const FORWARD_DIST = 1.2;
  const forward = Vector3Utils.scale(viewDir, FORWARD_DIST);
  let right = { x: -viewDir.z, y: 0, z: viewDir.x };
  const rightLen = Math.sqrt(right.x * right.x + right.y * right.y + right.z * right.z);
  if (rightLen < 1e-4) {
    right = { x: 1, y: 0, z: 0 };
  } else {
    right.x /= rightLen;
    right.y /= rightLen;
    right.z /= rightLen;
  }
  const rightOffset = Vector3Utils.scale(right, 0.22);
  const spawnLoc = Vector3Utils.add(Vector3Utils.add(headPos, forward), rightOffset);
  return spawnLoc;
}
function fireBullet(player, gun) {
  const spawnLoc = getSpawnLoc(player, gun);
  if (gun.mode === "shotgun" /* SHOTGUN */) {
    const PELLETS = 4;
    const spread = 0.1;
    const forward = player.getViewDirection();
    let right = { x: -forward.z, y: 0, z: forward.x };
    const rightLen = Math.sqrt(right.x * right.x + right.y * right.y + right.z * right.z);
    if (rightLen < 1e-4) {
      right = { x: 1, y: 0, z: 0 };
    } else {
      right.x /= rightLen;
      right.y /= rightLen;
      right.z /= rightLen;
    }
    const up = {
      x: forward.y * right.z - forward.z * right.y,
      y: forward.z * right.x - forward.x * right.z,
      z: forward.x * right.y - forward.y * right.x
    };
    for (let i = 0; i < PELLETS; i++) {
      const rx = (Math.random() * 2 - 1) * spread;
      const ry = (Math.random() * 2 - 1) * spread;
      let dir = {
        x: forward.x + right.x * rx + up.x * ry,
        y: forward.y + right.y * rx + up.y * ry,
        z: forward.z + right.z * rx + up.z * ry
      };
      const len = Math.sqrt(dir.x * dir.x + dir.y * dir.y + dir.z * dir.z);
      if (len > 1e-6) {
        dir.x /= len;
        dir.y /= len;
        dir.z /= len;
      }
      const pellet = player.dimension.spawnEntity(gun.projectileTypeId, spawnLoc);
      if (!pellet) continue;
      try {
        pellet.addTag(`abg_weapon:${gun.id}`);
      } catch {
      }
      try {
        pellet.spawnLocation = spawnLoc;
      } catch {
      }
      const proj = pellet.getComponent("minecraft:projectile");
      if (proj) {
        proj.shoot(Vector3Utils.scale(dir, gun.shootPower * 0.95), { uncertainty: gun.uncertainty || 0 });
      }
    }
    return;
  }
  const bullet = player.dimension.spawnEntity(gun.projectileTypeId, spawnLoc);
  if (!bullet) return;
  try {
    bullet.addTag(`abg_weapon:${gun.id}`);
  } catch {
  }
  try {
    bullet.spawnLocation = spawnLoc;
  } catch {
  }
  const projectileComponent = bullet.getComponent("minecraft:projectile");
  if (projectileComponent) {
    const direction = player.getViewDirection();
    projectileComponent.shoot(Vector3Utils.scale(direction, gun.shootPower), {
      uncertainty: gun.uncertainty || 0
    });
  }
}
function fireVfx(player, gun) {
  try {
    const soundToPlay = gun.shootSound && String(gun.shootSound).toLowerCase() !== "none" ? gun.shootSound : "gun.shoot";
    player.playSound(soundToPlay, { volume: 4, pitch: 1 });
    player.playAnimation("animation.recoil.generic");
    player.runCommand(`camerashake add @s ${gun.recoil} 0.1 rotational`);
  } catch {
  }
}

// scripts/feature/ui.ts
import { system } from "@minecraft/server";

// scripts/feature/utils/inventoryUtils.ts
function getInventoryComponent(player) {
  const inv = player.getComponent("minecraft:inventory");
  return inv ?? null;
}
function getContainer(player) {
  const inv = getInventoryComponent(player);
  return inv ? inv.container : null;
}
function getHeldItem(player) {
  const container = getContainer(player);
  if (!container) return null;
  return container.getItem(player.selectedSlotIndex);
}

// scripts/feature/utils/gunUtils.ts
function getHeldGun(player) {
  const held = getHeldItem(player);
  if (!held) return void 0;
  return GUNS.find((g) => g.id === held.typeId);
}
function ensurePlayerGunInitialized(player, gun) {
  ensurePlayerAmmoInitialized(player, gun);
}
function getCurrentAmmo(player, gun) {
  return getPlayerAmmo(player, gun);
}
function hasAmmoInContainer(container, ammoTypeId) {
  if (!container) return false;
  for (let i = 0; i < container.size; i++) {
    const item = container.getItem(i);
    if (item && item.typeId === ammoTypeId && item.amount > 0) return true;
  }
  return false;
}
function findAndConsumeAmmo(container, ammoTypeId) {
  if (!container) return false;
  for (let i = 0; i < container.size; i++) {
    const item = container.getItem(i);
    if (item && item.typeId === ammoTypeId && item.amount > 0) {
      if (item.amount > 1) {
        item.amount--;
        container.setItem(i, item);
      } else {
        container.setItem(i, void 0);
      }
      return true;
    }
  }
  return false;
}

// scripts/feature/ui.ts
function updateActionBar(player) {
  const container = getContainer(player);
  if (!container) return;
  const gun = getHeldGun(player);
  if (!gun) {
    player.onScreenDisplay.setTitle(`ammo:""`);
    system.runTimeout(() => {
      player.onScreenDisplay.setTitle(`ammo2:""`);
    }, 2);
    return;
  }
  // ✅ CHANGED: Check if THIS gun is reloading
  const reloadData = playerReloadCooldowns.get(player.id);
  if (reloadData && reloadData.gunId === gun.id && reloadData.ticksRemaining > 0) {
    player.onScreenDisplay.setTitle(`ammo:"\xA7cR.."`);
    return;
  }
  const currentAmmo = getPlayerAmmo(player, gun);
  player.onScreenDisplay.setTitle(`ammo:[${currentAmmo}]`, {
    stayDuration: 1,
    fadeInDuration: 1,
    fadeOutDuration: 1
  });
  system.runTimeout(() => {
    player.onScreenDisplay.setTitle(`ammo2:[${gun.maxAmmo}]`, {
      stayDuration: 1,
      fadeInDuration: 1,
      fadeOutDuration: 1
    });
  }, 2);
}
function setShootMessage(player) {
  const gun = getHeldGun(player);
  if (!gun) {
    return;
  }
  const currentAmmo = getPlayerAmmo(player, gun);
  player.onScreenDisplay.setTitle(`ammo:[${currentAmmo}]`, {
    stayDuration: 1,
    fadeInDuration: 1,
    fadeOutDuration: 1
  });
}
function setReloadingMessage(player) {
  const gun = getHeldGun(player);
  if (!gun) return;
  player.onScreenDisplay.setTitle(`ammo:"\xA7cR.."`);
}
function setReloadedMessage(player) {
  const gun = getHeldGun(player);
  if (!gun) return;
  player.onScreenDisplay.setTitle(`ammo:"\xA72R"`);
  system.runTimeout(() => {
    setShootMessage(player);
  }, 10);
}
function setOutOfAmmoMessage(player) {
  const gun = getHeldGun(player);
  if (!gun) return;
  player.onScreenDisplay.setTitle(`ammo:\xA7c[0]`);
}

// scripts/feature/shoot.ts
function shoot(player, gun) {
  const decreaseAmmo = decreasePlayerAmmo(player, gun);
  if (!decreaseAmmo) return;
  fireVfx(player, gun);
  fireBullet(player, gun);
  setShootMessage(player);
  try {
    player.playAnimation(gun.shootAnimation ?? "animation.abg3.shoot");
  } catch {
  }
  playerFireCooldowns.set(player.id, gun.fireRate);
}

// scripts/feature/reload.ts
// ✅ CHANGED: Store gunId with reload timer
function startReload(player, gun) {
  const container = getContainer(player);
  if (!container) return false;
  if (!hasAmmoInContainer(container, gun.ammoTypeId)) return false;
  try {
    player.playAnimation(gun.reloadAnimation ?? "animation.abg3.reload");
  } catch {
  }
  playerReloadCooldowns.set(player.id, {
    gunId: gun.id,
    ticksRemaining: gun.reloadTime
  });
  return true;
}
// ✅ CHANGED: Validate gun match and ammo consumption
function completeReload(player, gun) {
  const container = getContainer(player);
  if (!container) return;

  // Only refill if ammo consumption succeeds
  if (findAndConsumeAmmo(container, gun.ammoTypeId)) {
    setPlayerAmmo(player, gun, gun.maxAmmo);
  }
}

// scripts/feature/utils/durabilityUtils.ts
function applyDurabilityDamage(player, itemUsed, amount = 1) {
  if (!itemUsed) return;
  const durComp = itemUsed.getComponent("minecraft:durability");
  if (!durComp) return;
  durComp.damage = (durComp.damage ?? 0) + amount;
  const maxDurability = durComp.maxDurability ?? durComp.max_durability ?? 100;
  const currentDamage = durComp.damage ?? 0;
  const inv = player.getComponent("minecraft:inventory");
  const slot = player.selectedSlotIndex ?? 0;
  if (currentDamage >= maxDurability) {
    try {
      player.playSound("random.break", { volume: 0.8, pitch: 0.9 });
    } catch {
    }
    try {
      if (inv && inv.container) inv.container.setItem(slot, void 0);
    } catch {
    }
  } else {
    try {
      if (inv && inv.container) inv.container.setItem(slot, itemUsed);
    } catch {
    }
  }
}

// scripts/feature/throwingKnife.ts
function throwTacticalKnife(player, itemStack) {
  if (!itemStack || itemStack.typeId !== "absolute_guns:tactical_knife_scope") return;
  const throwKnife = player.dimension.spawnEntity(
    "absolute_guns_bullet:tactical_knife_scope2",
    Vector3Utils.add(player.getHeadLocation(), Vector3Utils.scale(player.getViewDirection(), 1.5))
  );
  if (!throwKnife) return;
  const proj = throwKnife.getComponent("minecraft:projectile");
  if (proj) {
    proj.shoot(Vector3Utils.scale(player.getViewDirection(), 2));
  }
  try {
    player.playSound("gun.abgawm", { volume: 6, pitch: 1.2 });
    player.runCommand(`camerashake add @s 0.23 0.2 rotational`);
  } catch {
  }
  const held = getHeldItem(player);
  if (held) applyDurabilityDamage(player, held);
}
function modifyMovement(player) {
  const held = getHeldItem(player);
  if (held?.typeId != "absolute_guns:tactical_knife_scope") return;
  if (player.isSneaking) player.addEffect(`slowness`, 4, { amplifier: 8, showParticles: false });
}

// scripts/feature/damageHandler.ts
import { EquipmentSlot } from "@minecraft/server";
var ARMOR_PROTECTION_VALUES = {
  "minecraft:netherite_helmet": { toughness: 3, protection: 4, knockback_resistance: 1 },
  "minecraft:netherite_chestplate": { toughness: 8, protection: 4, knockback_resistance: 1 },
  "minecraft:netherite_leggings": { toughness: 6, protection: 4, knockback_resistance: 1 },
  "minecraft:netherite_boots": { toughness: 3, protection: 4, knockback_resistance: 1 },
  "minecraft:diamond_helmet": { toughness: 2, protection: 3 },
  "minecraft:diamond_chestplate": { toughness: 2, protection: 8 },
  "minecraft:diamond_leggings": { toughness: 2, protection: 6 },
  "minecraft:diamond_boots": { toughness: 2, protection: 3 },
  "minecraft:iron_helmet": { toughness: 0, protection: 2 },
  "minecraft:iron_chestplate": { toughness: 0, protection: 6 },
  "minecraft:iron_leggings": { toughness: 0, protection: 5 },
  "minecraft:iron_boots": { toughness: 0, protection: 2 },
  "minecraft:chainmail_helmet": { toughness: 0, protection: 2 },
  "minecraft:chainmail_chestplate": { toughness: 0, protection: 5 },
  "minecraft:chainmail_leggings": { toughness: 0, protection: 4 },
  "minecraft:chainmail_boots": { toughness: 0, protection: 1 },
  "minecraft:golden_helmet": { toughness: 0, protection: 2 },
  "minecraft:golden_chestplate": { toughness: 0, protection: 5 },
  "minecraft:golden_leggings": { toughness: 0, protection: 3 },
  "minecraft:golden_boots": { toughness: 0, protection: 1 },
  "minecraft:leather_helmet": { toughness: 0, protection: 1 },
  "minecraft:leather_chestplate": { toughness: 0, protection: 3 },
  "minecraft:leather_leggings": { toughness: 0, protection: 2 },
  "minecraft:leather_boots": { toughness: 0, protection: 1 },
  "minecraft:turtle_helemt": { toughness: 0, protection: 1 }
};
function distanceBetween(a, b) {
  if (!a || !b) return 0;
  const dx = (a.x || 0) - (b.x || 0);
  const dy = (a.y || 0) - (b.y || 0);
  const dz = (a.z || 0) - (b.z || 0);
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
}
var DamageHandler = class _DamageHandler {
  static getDamageTakenWithProtection(armorProtection, ArmorToughness, damage, enchantLevel) {
    try {
      const safeEnchant = Math.max(1, enchantLevel || 1);
      const safeToughness = Math.max(1, ArmorToughness || 1);
      const top = Math.max(
        armorProtection / 5,
        armorProtection - (4 * damage * (1 / safeEnchant) / safeToughness + 8)
      );
      let res = 1 - top / 25;
      if (!Number.isFinite(res)) res = 1;
      return Math.min(Math.max(res, 0), 1);
    } catch {
      return 1;
    }
  }
  static handleArmorDurability(entity, damage) {
    try {
      const equipment = entity.getComponent("equippable") ?? entity.getComponent("equipment") ?? entity.getComponent("minecraft:equipment");
      if (!equipment) return;
      const damageInHeart = damage * 2;
      const durabilityDamage = damageInHeart / 4;
      const slots = [EquipmentSlot.Head, EquipmentSlot.Chest, EquipmentSlot.Legs, EquipmentSlot.Feet];
      for (const s of slots) {
        try {
          const item = equipment.getEquipment(s);
          if (!item) continue;
          const comp = item.getComponent("minecraft:durability") ?? item.getComponent("durability");
          if (!comp) continue;
          comp.damage = (comp.damage ?? 0) + durabilityDamage;
          equipment.setEquipment(s, item);
        } catch {
        }
      }
    } catch {
    }
  }
  static getKnockbackResistance(hit) {
    try {
      const equipment = hit.getComponent("equippable") ?? hit.getComponent("equipment") ?? hit.getComponent("minecraft:equipment");
      if (!equipment) return 1;
      const head = equipment.getEquipment(EquipmentSlot.Head);
      const chest = equipment.getEquipment(EquipmentSlot.Chest);
      const legs = equipment.getEquipment(EquipmentSlot.Legs);
      const feet = equipment.getEquipment(EquipmentSlot.Feet);
      const helmet = ARMOR_PROTECTION_VALUES[head?.typeId]?.knockback_resistance || 0;
      const chestR = ARMOR_PROTECTION_VALUES[chest?.typeId]?.knockback_resistance || 0;
      const legsR = ARMOR_PROTECTION_VALUES[legs?.typeId]?.knockback_resistance || 0;
      const feetR = ARMOR_PROTECTION_VALUES[feet?.typeId]?.knockback_resistance || 0;
      const total = helmet + chestR + legsR + feetR;
      return Math.max(0, 1 - total * 0.07);
    } catch {
      return 1;
    }
  }
  static handleArmorMultiplier(hit, damage) {
    try {
      const equipment = hit.getComponent("equippable") ?? hit.getComponent("equipment") ?? hit.getComponent("minecraft:equipment");
      if (!equipment) return 1;
      const head = equipment.getEquipment(EquipmentSlot.Head);
      const chest = equipment.getEquipment(EquipmentSlot.Chest);
      const legs = equipment.getEquipment(EquipmentSlot.Legs);
      const feet = equipment.getEquipment(EquipmentSlot.Feet);
      const helmetProtection = ARMOR_PROTECTION_VALUES[head?.typeId]?.protection || 0;
      const chestProtection = ARMOR_PROTECTION_VALUES[chest?.typeId]?.protection || 0;
      const legsProtection = ARMOR_PROTECTION_VALUES[legs?.typeId]?.protection || 0;
      const feetProtection = ARMOR_PROTECTION_VALUES[feet?.typeId]?.protection || 0;
      const maxProtection = helmetProtection + chestProtection + legsProtection + feetProtection;
      const helmetToughness = ARMOR_PROTECTION_VALUES[head?.typeId]?.toughness || 0;
      const chestToughness = ARMOR_PROTECTION_VALUES[chest?.typeId]?.toughness || 0;
      const legsToughness = ARMOR_PROTECTION_VALUES[legs?.typeId]?.toughness || 0;
      const feetToughness = ARMOR_PROTECTION_VALUES[feet?.typeId]?.toughness || 0;
      const maxToughness = helmetToughness + chestToughness + legsToughness + feetToughness;
      const helmetEnchant = head?.getComponent("enchantable")?.getEnchantment("protection")?.level || 0;
      const chestEnchant = chest?.getComponent("enchantable")?.getEnchantment("protection")?.level || 0;
      const legsEnchant = legs?.getComponent("enchantable")?.getEnchantment("protection")?.level || 0;
      const feetEnchant = feet?.getComponent("enchantable")?.getEnchantment("protection")?.level || 0;
      const totalEnchants = helmetEnchant + chestEnchant + legsEnchant + feetEnchant;
      return _DamageHandler.getDamageTakenWithProtection(maxProtection, maxToughness, damage, totalEnchants) || 1;
    } catch {
      return 1;
    }
  }
  static getDamages(weapon, hit, bullet) {
    try {
      const spawn = bullet.spawnLocation || bullet.location || { x: 0, y: 0, z: 0 };
      const dist = Math.floor(distanceBetween(spawn, hit.location));
      const raw = (weapon.damage || 0) - (weapon.damageDropOff || 0) * dist;
      if (raw <= 0) return 0;
      const m = _DamageHandler.handleArmorMultiplier(hit, raw);
      const pen = weapon.armorPenetration ?? 0;
      const final = raw * (m * (1 - pen) + pen);
      return Math.max(0, final);
    } catch {
      return 0;
    }
  }
};

// scripts/main.ts
var GameController = class {
  constructor() {
    this.playerShooting = /* @__PURE__ */ new Map();
    this.lastHeldGun = /* @__PURE__ */ new Map();
    this.registerEvents();
    this.GameLoop();
  }
  registerEvents() {
    world2.afterEvents.itemStartUse.subscribe((event) => this.afterItemStartUse(event));
    world2.afterEvents.itemReleaseUse.subscribe((event) => this.afterItemReleaseUse(event));
    world2.afterEvents.playerLeave.subscribe((event) => this.afterPlayerLeave(event));
    world2.afterEvents.playerJoin.subscribe((event) => this.afterPlayerJoin(event));
    world2.afterEvents.itemUse.subscribe((event) => this.afterItemUse(event));
    world2.afterEvents.projectileHitEntity.subscribe((event) => this.afterProjectileHitEntity(event));
    world2.afterEvents.playerBreakBlock.subscribe((event) => this.afterPlayerBreakBlock(event));
  }
  afterPlayerBreakBlock(event) {
    const player = event.player;
    const itemStack = getHeldItem(player);
    if (itemStack && itemStack.typeId === "absolute_guns:tactical_knife_scope") {
      applyDurabilityDamage(player, itemStack);
    }
  }
  afterProjectileHitEntity(event) {
    try {
      const projectile = event?.projectile ?? event?.projectileEntity;
      const shooter = event?.source ?? event?.sourceEntity ?? null;
      const hitInfo = typeof event?.getEntityHit === "function" ? event.getEntityHit() : void 0;
      const hitEntity = hitInfo?.entity ?? event?.entity;
      if (!hitEntity || !projectile) return;
      if (hitEntity.typeId === "minecraft:player") return;
      let weaponId;
      try {
        const tags = typeof projectile.getTags === "function" ? projectile.getTags() : [];
        for (const t of tags || []) {
          if (typeof t === "string" && t.startsWith("abg_weapon:")) {
            weaponId = t.slice("abg_weapon:".length);
            break;
          }
        }
      } catch {
      }
      let gun = weaponId ? GUNS.find((g) => g.id === weaponId) : void 0;
      if (!gun) gun = GUNS.find((g) => g.projectileTypeId === projectile.typeId);
      if (!gun) return;
      const stats = gun.stats;
      if (!stats) return;
      const bullet = projectile;
      if (!bullet.spawnLocation) bullet.spawnLocation = bullet.location;
      const damage = DamageHandler.getDamages(stats, hitEntity, bullet);
      if (!damage || damage <= 0) return;
      try {
        hitEntity.applyDamage(damage, {
          cause: EntityDamageCause.override,
          damagingProjectile: projectile,
          damagingEntity: shooter
        });
      } catch {
      }
      try {
        const direction = shooter ? shooter.getViewDirection() : { x: 0, y: 0, z: 0 };
        const knockbackRes = DamageHandler.getKnockbackResistance(hitEntity);
        const kbX = (stats.knockback?.x || 0) * knockbackRes;
        const kbY = (stats.knockback?.y || 0) * knockbackRes;
        if (typeof hitEntity.applyKnockback === "function") {
          hitEntity.applyKnockback(direction.x, direction.z, kbX, kbY);
        }
      } catch {
      }
      try {
        DamageHandler.handleArmorDurability(hitEntity, damage);
      } catch {
      }
    } catch {
    }
  }
  afterItemUse(event) {
    const { source: player, itemStack } = event;
    throwTacticalKnife(player, itemStack);
  }
  afterPlayerJoin(event) {
    try {
      const joinedPlayer = event && (event.player ?? world2.getAllPlayers().find((p) => p.id === event.playerId));
      if (joinedPlayer) {
        const held = getHeldGun(joinedPlayer);
        this.lastHeldGun.set(joinedPlayer.id, held ? held.id : null);
        if (held) {
          try {
            ensurePlayerGunInitialized(joinedPlayer, held);
          } catch {
          }
        }
      }
    } catch {
    }
    const messages = [
      `Thx for playing DeadWire!`
    ];
    messages.forEach((m) => {
      system2.runTimeout(() => {
        world2.getAllPlayers().forEach((p) => p.playSound("random.levelup", { volume: 0.0, pitch: 1 }));
        world2.sendMessage(m);
      }, 200 + 20 * 2 * (messages.indexOf(m) + 1));
    });
  }
  afterItemStartUse(event) {
    const { source: player, itemStack } = event;
    const gun = getHeldGun(player) || GUNS.find((g) => g.id === itemStack.typeId);
    if (!gun) return;
    ensurePlayerGunInitialized(player, gun);
    const currentAmmo = getCurrentAmmo(player, gun);

    // ✅ CHANGED: Check if THIS gun is reloading
    const reloadData = playerReloadCooldowns.get(player.id);
    if (reloadData && reloadData.gunId === gun.id && reloadData.ticksRemaining > 0) return;

    if (currentAmmo <= 0) {
      const started = startReload(player, gun);
      if (started) setReloadingMessage(player);
      else setOutOfAmmoMessage(player);
    } else {
      this.playerShooting.set(player.id, true);
    }
  }
  afterItemReleaseUse(event) {
    const { source: player, itemStack } = event;
    const gun = GUNS.find((g) => g.id === itemStack?.typeId);
    if (!gun) return;
    this.playerShooting.set(player.id, false);
  }
  afterPlayerLeave(event) {
    const playerId = event.playerId;
    playerFireCooldowns.delete(playerId);
    playerReloadCooldowns.delete(playerId);
    this.playerShooting.delete(playerId);
    this.lastHeldGun.delete(playerId);
  }
  GameLoop() {
    this.tickId = system2.runInterval(() => {
      for (const player of world2.getAllPlayers()) {
        modifyMovement(player);
        const currentlyHeld = getHeldGun(player);
        const currentHeldId = currentlyHeld ? currentlyHeld.id : null;
        const hadEntry = this.lastHeldGun.has(player.id);
        const prevHeldId = hadEntry ? this.lastHeldGun.get(player.id) || null : null;

        // ✅ CHANGED: Cancel reload on weapon swap
        if (currentHeldId !== prevHeldId) {
          const reloadData = playerReloadCooldowns.get(player.id);
          if (reloadData) {
            playerReloadCooldowns.delete(player.id);
          }

          if (currentlyHeld) {
            try {
              ensurePlayerGunInitialized(player, currentlyHeld);
            } catch {
            }
            try {
              player.playAnimation(currentlyHeld.drawAnimation ?? "animation.abg3.draw");
            } catch {
            }
          }
          this.lastHeldGun.set(player.id, currentHeldId);
        }
        if (this.playerShooting.get(player.id)) {
          const gun = getHeldGun(player);
          if (!gun) {
            this.playerShooting.set(player.id, false);
          } else {
            // ✅ CHANGED: Check if THIS gun is reloading
            const reloadData = playerReloadCooldowns.get(player.id);
            const isReloading = reloadData && reloadData.gunId === gun.id && reloadData.ticksRemaining > 0;
            const currentAmmo = getCurrentAmmo(player, gun);
            if (currentAmmo > 0 && !isReloading && this.playerShooting.get(player.id) === true) {
              if ((playerFireCooldowns.get(player.id) || 0) === 0) {
                shoot(player, gun);
              }
            }
          }
        }
        const fireCooldown = playerFireCooldowns.get(player.id);
        if (fireCooldown && fireCooldown > 0) {
          playerFireCooldowns.set(player.id, fireCooldown - 1);
        }

        // ✅ CHANGED: Updated reload countdown logic
        const reloadData = playerReloadCooldowns.get(player.id);
        if (reloadData && reloadData.ticksRemaining > 0) {
          playerReloadCooldowns.set(player.id, {
            ...reloadData,
            ticksRemaining: reloadData.ticksRemaining - 1
          });

          if (reloadData.ticksRemaining - 1 === 0) {
            const gun = getHeldGun(player);

            // ✅ CHANGED: Only reload if still holding the SAME gun
            if (gun && gun.id === reloadData.gunId) {
              const inventory = player.getComponent("minecraft:inventory");
              if (inventory?.container) {
                completeReload(player, gun);

                // ✅ CHANGED: Check if reload actually succeeded
                const newAmmo = getPlayerAmmo(player, gun);
                if (newAmmo === gun.maxAmmo) {
                  setReloadedMessage(player);
                } else {
                  // Ammo vanished mid-reload
                  setOutOfAmmoMessage(player);
                }
              }
            }

            playerReloadCooldowns.delete(player.id);
          }
        }
      }
    }, 1);
    system2.runInterval(() => {
      const dims = ["minecraft:overworld", "minecraft:nether", "minecraft:the_end"];
      for (const dimId of dims) {
        const dim = world2.getDimension(dimId);
        const entities = dim.getEntities();
        for (const entity of entities) {
          if (entity.typeId.startsWith("absolute_guns_bullet:")) {
            const gun = GUNS.find((g) => g.projectileTypeId === entity.typeId);
            if (gun && gun.stats && gun.stats.maxRange) {
              const spawnLoc = entity.spawnLocation;
              if (spawnLoc) {
                const dist = distanceBetween(spawnLoc, entity.location);
                if (dist > gun.stats.maxRange) {
                  entity.remove();
                }
              }
            }
          }
        }
      }
    }, 1);
    const UILoopId = system2.runInterval(() => {
      for (const player of world2.getAllPlayers()) {
        updateActionBar(player);
      }
    }, 4);
  }
};
new GameController();

//# sourceMappingURL=../debug/main.js.map